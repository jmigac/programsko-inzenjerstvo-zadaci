﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak78
{
    class Dogadaj
    {
        private string _nazivDogadaja;
        public static List<Dogadaj> SviDogadaji = new List<Dogadaj>();
        public string NazivDogadaja { get => _nazivDogadaja;
            set
            {
                if (value.Length < 1)
                    throw new NazivDogadajaJeNeispravan("Unijeli ste 1 ili manje znakova!");
                else
                    _nazivDogadaja = value;
            }
        }
        public string UneseniDatum { get; set; }
        private DateTime ParseDatum { get; set; }
        public Dogadaj()
        {
            SviDogadaji.Add(this);
            ParseDatum = DateTime.Parse(UneseniDatum);
        }
        public override string ToString()
        {
            return this.NazivDogadaja + "-" + this.UneseniDatum;  
        }
        public static List<Dogadaj> SviDogadajiNakonX(int godinaX)
        {
            List<Dogadaj> DogadajiNakonGodineX = new List<Dogadaj>();
            foreach (var dogadajListe in SviDogadaji)
            {
                if (dogadajListe.ParseDatum.Year > godinaX)
                {
                    DogadajiNakonGodineX.Add(dogadajListe);
                }
            }
            return DogadajiNakonGodineX;
        }
    }
}
