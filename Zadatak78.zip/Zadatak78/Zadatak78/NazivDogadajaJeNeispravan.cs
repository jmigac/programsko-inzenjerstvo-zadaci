﻿using System;
using System.Runtime.Serialization;

namespace Zadatak78
{
    [Serializable]
    internal class NazivDogadajaJeNeispravan : Exception
    {
        public NazivDogadajaJeNeispravan()
        {
        }

        public NazivDogadajaJeNeispravan(string message) : base(message)
        {
        }

        public NazivDogadajaJeNeispravan(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected NazivDogadajaJeNeispravan(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}