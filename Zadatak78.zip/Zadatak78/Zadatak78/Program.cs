﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak78
{
    class Program
    {
        static void Main(string[] args)
        {
            string odabirIzbornika = "";
            string naslovDogadaja = "";
            string datumDogadaja = "";
            int godinaX;
            do
            {
                Console.WriteLine("1. Unijeti događaj u listu");
                Console.WriteLine("2. Ispis svih događaja");
                Console.WriteLine("3. Ispis svih događaja nakon godine X");
                Console.WriteLine("4. Ispis svih događaja s naslovom Y");
                Console.WriteLine("9. Izlaz");
                Console.WriteLine("Odaberi:");
                odabirIzbornika = Console.ReadLine();
                switch (odabirIzbornika)
                {
                    case "1":
                        {
                            Console.WriteLine("Naslov događaja:");
                            naslovDogadaja = Console.ReadLine();
                            Console.WriteLine("Datum događaja:");
                            datumDogadaja = Console.ReadLine();
                            Dogadaj dogadaj = new Dogadaj() { NazivDogadaja = naslovDogadaja,UneseniDatum=datumDogadaja };
                            break;
                        }
                    case "2":
                        {
                            foreach (var dogadaj in Dogadaj.SviDogadaji)
                            {
                                Console.WriteLine(dogadaj.ToString());
                            }

                            break;
                        }
                    case "3":
                        {
                            Console.WriteLine("Godina X za pregled:");
                            godinaX = int.Parse(Console.ReadLine());
                            break;
                        }
                    case "4":
                        {

                            break;
                        }
                }
            } while (odabirIzbornika != "9");
        }
    }
}
//DateTime Type --> "Jan 1, 2009"