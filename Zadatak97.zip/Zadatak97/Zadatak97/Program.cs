﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak97
{
    class Program
    {
        static void Main(string[] args)
        {
            //unesi filmove u listu
            //ispisati sve elemente liste
            //ispis svih filmova s ocjenom većom od X
            //ispis svih filmova koji sadrže pojam Y
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.WriteLine("# === IZBORNIK === #");
                Console.WriteLine("1. unos filma");
                Console.WriteLine("2. ispis svih filmova");
                Console.WriteLine("3. ispis filmova s vecom ocjenom od X");
                Console.WriteLine("4. ispis filmova s pojmom Y");
                Console.WriteLine("9. izlaz");
                Console.WriteLine("Odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                Console.WriteLine("# === IZBORNIK === #");
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            Console.WriteLine("Naziv filma:");
                            string nazivFilma = Console.ReadLine();
                            Console.WriteLine("Ocjena filma:");
                            int ocjena = int.Parse(Console.ReadLine());
                            if (!Film.ProvjeraDuplikataFilma(nazivFilma))
                            {
                                Film noviFilm = new Film(nazivFilma, ocjena);
                            }
                            break;
                        }
                    case 2:
                        {
                            Film.IspisivanjeFilmova();
                            Console.ReadLine();
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Unesi ocjenu:");
                            int upitOcjena = int.Parse(Console.ReadLine());
                            Film.IspisivanjeFilmovaOcjeneX(upitOcjena);
                            Console.ReadLine();
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Unesi string za pretragu:");
                            string upitString = Console.ReadLine();
                            Film.IspisFilmovaNazivaY(upitString);
                            Console.ReadLine();
                            break;
                        }
                }

            } while (odabirIzbornika != 9);

        }
    }
}
/*
1
IMF
5
1
RED
4
1
RED 2
3
1
Rocky
2
*/