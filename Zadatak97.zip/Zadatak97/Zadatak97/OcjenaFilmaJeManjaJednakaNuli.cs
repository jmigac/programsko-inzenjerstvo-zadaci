﻿using System;
using System.Runtime.Serialization;

namespace Zadatak97
{
    [Serializable]
    internal class OcjenaFilmaJeManjaJednakaNuli : Exception
    {
        public OcjenaFilmaJeManjaJednakaNuli()
        {
        }

        public OcjenaFilmaJeManjaJednakaNuli(string message) : base(message)
        {
        }

        public OcjenaFilmaJeManjaJednakaNuli(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected OcjenaFilmaJeManjaJednakaNuli(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}