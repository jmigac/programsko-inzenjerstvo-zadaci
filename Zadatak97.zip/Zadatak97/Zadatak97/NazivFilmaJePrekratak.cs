﻿using System;
using System.Runtime.Serialization;

namespace Zadatak97
{
    [Serializable]
    internal class NazivFilmaJePrekratak : Exception
    {
        public NazivFilmaJePrekratak()
        {
        }

        public NazivFilmaJePrekratak(string message) : base(message)
        {
        }

        public NazivFilmaJePrekratak(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected NazivFilmaJePrekratak(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}