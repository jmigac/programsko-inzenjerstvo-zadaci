﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak97
{
    class Film
    {
        public static List<Film> SviFilmovi = new List<Film>();
        private string _nazivFilma;
        private int _ocjenaFilma;
        public string NazivFilma { get => _nazivFilma;
            set
            {
                if (value.Length <= 2)
                    throw new NazivFilmaJePrekratak("Unijeli ste nepoželjan naziv filma!");
                else
                    _nazivFilma = value;
            }
                }
        public int OcjenaFilma { get => _ocjenaFilma;
            set
            {
                if (value <= 0)
                    throw new OcjenaFilmaJeManjaJednakaNuli("Da li ste nevažeću ocjenu filmu!");
                else
                    _ocjenaFilma = value;
            }
                }
        public Film(string naziv, int ocjena)
        {
            NazivFilma = naziv;
            OcjenaFilma = ocjena;
            SviFilmovi.Add(this);
        }
        public static bool ProvjeraDuplikataFilma(string nazivFilma)
        {
            foreach (var film in SviFilmovi)
            {
                if (film.NazivFilma.ToLower().Equals(nazivFilma.ToLower()))
                    return true;
            }
            return false;
        }
        public static void IspisivanjeFilmova()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            foreach (var film in SviFilmovi)
            {
                Console.WriteLine($"{film.NazivFilma} : {film.OcjenaFilma}");
            }
        }
        public static void IspisivanjeFilmovaOcjeneX(int ocjena)
        {
            foreach (var film in SviFilmovi)
            {
                if (film.OcjenaFilma > ocjena)
                    Console.WriteLine($"{film.NazivFilma} : {film.OcjenaFilma}");
            }
        }
        public static void IspisFilmovaNazivaY(string naziv)
        {
            foreach (var film in SviFilmovi)
            {
                if(film.NazivFilma.ToLower().Contains(naziv.ToLower()))
                    Console.WriteLine($"{film.NazivFilma} : {film.OcjenaFilma}");
            }
        }
    }
}
