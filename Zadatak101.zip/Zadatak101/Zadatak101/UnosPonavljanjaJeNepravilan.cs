﻿using System;
using System.Runtime.Serialization;

namespace Zadatak101
{
    [Serializable]
    internal class UnosPonavljanjaJeNepravilan : Exception
    {
        public UnosPonavljanjaJeNepravilan()
        {
        }

        public UnosPonavljanjaJeNepravilan(string message) : base(message)
        {
        }

        public UnosPonavljanjaJeNepravilan(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UnosPonavljanjaJeNepravilan(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}