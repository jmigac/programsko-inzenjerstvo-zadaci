﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak101
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             "Napravite konzolnu aplikaciju u kojoj korisnik unosi tekstove i broj ponavljanja pojedinog teksta. 
              Nakon unosa aplikacija ispisuje sav tekst u jednom redu broj puta odvojeno razmakom. 
              Tekstovi su međusobno odvojeni zarezom.
              U sklopu vašeg rješenja potrebno je napraviti i koristiti barem jednu iznimku" 
             */
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.WriteLine("1. unos teksta.");
                Console.WriteLine("2. ispis teksta.");
                Console.WriteLine("9. kraj");
                Console.WriteLine("odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            string tekst = "";
                            int brojPonavljanja;
                            Console.WriteLine("Unesite tekst:");
                            tekst = Console.ReadLine();
                            Console.WriteLine("Broj ponavljanja:");
                            brojPonavljanja = int.Parse(Console.ReadLine());
                            Tekst noviTekst = new Tekst(tekst, brojPonavljanja);
                            break;
                        }
                    case 2:
                        {
                            Tekst.IspisivanjeTekstova();
                            Console.ReadLine();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
/*
1
Tekst123
14
1
TekstoviSuDobri
21
1
Stoooormaj
4
*/