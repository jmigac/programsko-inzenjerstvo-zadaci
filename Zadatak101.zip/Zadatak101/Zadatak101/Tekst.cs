﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak101
{
    class Tekst
    {
        public static List<Tekst> SviTekstovi = new List<Tekst>();
        private int _brojPonavljanja;
        public int BrojPonavljanja { get => _brojPonavljanja;
            set
            {
                if (value <= 0)
                    throw new UnosPonavljanjaJeNepravilan("Tekst se ne može ponavljati 0 ili manje od nula puta!");
                else
                    _brojPonavljanja = value;
            }
                }
        public string OdabraniTekst { get; set; }

        public Tekst(string uneseniTekst, int ponavljanje)
        {
            BrojPonavljanja = ponavljanje;
            OdabraniTekst = uneseniTekst;
            SviTekstovi.Add(this);
        }
        public static void IspisivanjeTekstova()
        {
            foreach (var tekst in SviTekstovi)
            {
                for(int i = 0; i < tekst.BrojPonavljanja; i++)
                {
                    Console.Write(tekst.OdabraniTekst);
                    if(i!=tekst.BrojPonavljanja-1)
                        Console.Write(", ");
                }
                Console.WriteLine(", ");
            }
        }
    }
}
