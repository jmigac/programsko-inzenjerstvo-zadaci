﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak81
{
    class Osoba
    {
        public static List<Osoba> SveOsobe = new List<Osoba>();
        public List<string> SviTelefoniOsobe = new List<string>();
        private string _imePrezime;
        public string ImePrezime { get => _imePrezime;
            set
            {
                if (value.Length <= 2)
                    throw new Iznimka("Ime je neispravno!");
                else _imePrezime = value;
            }
                }

        public Osoba(string imePrezime)
        {
            ImePrezime = imePrezime;
            UnosTelefona();
            SveOsobe.Add(this);
        }
        private void UnosTelefona()
        {
            int ponovanUnos = 1;
            string brojMobitela;
            do
            {
                Console.WriteLine("Unesi broj mobitela:");
                brojMobitela = Console.ReadLine();
                SviTelefoniOsobe.Add(brojMobitela);
                Console.WriteLine("Ponovan unos? 9-izlaz");
                ponovanUnos = int.Parse(Console.ReadLine());
            } while (ponovanUnos != 9);
        }
        public static void IspisivanjeSvihOsoba()
        {
            foreach (var osoba in SveOsobe)
            {
                Console.WriteLine(osoba.ImePrezime);
            }
        }
        public static void PretrazivanjeOsoba(string imeOsobe)
        {
            foreach (var osoba in SveOsobe)
            {
                if (osoba.ImePrezime.ToLower().Contains(imeOsobe.ToLower()))
                {
                    Console.WriteLine($"{osoba.ImePrezime}");
                    foreach (var broj in osoba.SviTelefoniOsobe)
                    {
                        Console.WriteLine($"    {broj}");
                    }
                }
            }
        }
    }
}
