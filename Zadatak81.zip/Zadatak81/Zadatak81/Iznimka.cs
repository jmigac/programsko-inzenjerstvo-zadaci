﻿using System;
using System.Runtime.Serialization;

namespace Zadatak81
{
    [Serializable]
    internal class Iznimka : Exception
    {
        public Iznimka()
        {
        }

        public Iznimka(string message) : base(message)
        {
        }

        public Iznimka(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected Iznimka(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}