﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak81
{
    class Program
    {
        static void Main(string[] args)
        {
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("# === IZBORNIK === #");
                Console.WriteLine("1. unos osobe i broja telefona");
                Console.WriteLine("2. ispis svih osoba");
                Console.WriteLine("3. pretraga po imenu");
                Console.WriteLine("9. kraj");
                Console.WriteLine("Odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                Console.WriteLine("# === IZBORNIK === #");
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            string imePrezime;
                            Console.WriteLine("Unesi ime i prezime osobe:");
                            imePrezime = Console.ReadLine();
                            Osoba novaOsoba = new Osoba(imePrezime);
                            break;
                        }
                    case 2:
                        {
                            Osoba.IspisivanjeSvihOsoba();
                            Console.ReadKey();
                            break;
                        }
                    case 3:
                        {
                            string imeOsobe;
                            Console.WriteLine("Upiši ime za pretragu:");
                            imeOsobe = Console.ReadLine();
                            Osoba.PretrazivanjeOsoba(imeOsobe);
                            Console.ReadKey();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
