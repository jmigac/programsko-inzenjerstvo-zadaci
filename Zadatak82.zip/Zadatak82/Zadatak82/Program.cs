﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak82
{
    class Program
    {
        static void Main(string[] args)
        {
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("# === IZBORNIK === #");
                Console.WriteLine("1. unos novog prijatelja");
                Console.WriteLine("2. ispis svih prijatelja");
                Console.WriteLine("3. sortirani prijatelji po ocjeni");
                Console.WriteLine("9. kraj");
                Console.WriteLine("Odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                Console.WriteLine("# === IZBORNIK === #");
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            string imePrezime;
                            int ocjena;
                            Console.WriteLine("Unesi ime i prezime:");
                            imePrezime = Console.ReadLine();
                            Console.WriteLine("Unesi ocjenu:");
                            ocjena = int.Parse(Console.ReadLine());
                            Prijatelj noviFrend = new Prijatelj(imePrezime, ocjena);
                            break;
                        }
                    case 2:
                        {
                            Prijatelj.IspisivanjeSvihPrijatelja();
                            Console.ReadKey();
                            break;
                        }
                    case 3:
                        {
                            Prijatelj.IspisPrijateljaOdNajboljeOcjene();
                            Console.ReadKey();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
