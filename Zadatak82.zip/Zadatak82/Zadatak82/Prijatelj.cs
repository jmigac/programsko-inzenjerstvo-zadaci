﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak82
{
    class Prijatelj
    {
        public static List<Prijatelj> SviPrijatelji = new List<Prijatelj>();
        public string ImePrezime { get; set; }
        public int OcjenaPrijatelja { get; set; }

        public Prijatelj(string imePrezime, int ocjena)
        {
            ImePrezime = imePrezime;
            OcjenaPrijatelja = ocjena;
            SviPrijatelji.Add(this);
        }
        public static void IspisivanjeSvihPrijatelja()
        {
            foreach (var prijatelj in SviPrijatelji)
            {
                Console.WriteLine($"{prijatelj.ImePrezime} - {prijatelj.OcjenaPrijatelja}");
            }
        }
        public static void IspisPrijateljaOdNajboljeOcjene()
        {
            SviPrijatelji.Sort((a, b) => (a.OcjenaPrijatelja.CompareTo(b.OcjenaPrijatelja)));
            foreach (var prijatelj in SviPrijatelji)
            {
                Console.WriteLine($"{prijatelj.ImePrezime} - {prijatelj.OcjenaPrijatelja}");
            }
        }
    }
}
