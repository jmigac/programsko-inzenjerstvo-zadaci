﻿namespace Zadatak135
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtKalkulator = new System.Windows.Forms.TextBox();
            this.BtnDva = new System.Windows.Forms.Button();
            this.BtnJedan = new System.Windows.Forms.Button();
            this.BtnTri = new System.Windows.Forms.Button();
            this.BtnCetiri = new System.Windows.Forms.Button();
            this.BtnPet = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.BtnSest = new System.Windows.Forms.Button();
            this.BtnNula = new System.Windows.Forms.Button();
            this.BtnDecimal = new System.Windows.Forms.Button();
            this.BtnMinus = new System.Windows.Forms.Button();
            this.BtnPlus = new System.Windows.Forms.Button();
            this.BtnMnozenje = new System.Windows.Forms.Button();
            this.BtnPodjeljeno = new System.Windows.Forms.Button();
            this.BtnSedam = new System.Windows.Forms.Button();
            this.BtnOsam = new System.Windows.Forms.Button();
            this.BtnDevet = new System.Windows.Forms.Button();
            this.BtnJednako = new System.Windows.Forms.Button();
            this.BtnOcisti = new System.Windows.Forms.Button();
            this.TxtRezultat = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // TxtKalkulator
            // 
            this.TxtKalkulator.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtKalkulator.Location = new System.Drawing.Point(13, 13);
            this.TxtKalkulator.Name = "TxtKalkulator";
            this.TxtKalkulator.Size = new System.Drawing.Size(270, 32);
            this.TxtKalkulator.TabIndex = 0;
            // 
            // BtnDva
            // 
            this.BtnDva.Location = new System.Drawing.Point(68, 81);
            this.BtnDva.Name = "BtnDva";
            this.BtnDva.Size = new System.Drawing.Size(49, 45);
            this.BtnDva.TabIndex = 1;
            this.BtnDva.Text = "2";
            this.BtnDva.UseVisualStyleBackColor = true;
            this.BtnDva.Click += new System.EventHandler(this.BtnDva_Click);
            // 
            // BtnJedan
            // 
            this.BtnJedan.Location = new System.Drawing.Point(13, 81);
            this.BtnJedan.Name = "BtnJedan";
            this.BtnJedan.Size = new System.Drawing.Size(49, 45);
            this.BtnJedan.TabIndex = 1;
            this.BtnJedan.Text = "1";
            this.BtnJedan.UseVisualStyleBackColor = true;
            this.BtnJedan.Click += new System.EventHandler(this.BtnJedan_Click);
            // 
            // BtnTri
            // 
            this.BtnTri.Location = new System.Drawing.Point(123, 81);
            this.BtnTri.Name = "BtnTri";
            this.BtnTri.Size = new System.Drawing.Size(49, 45);
            this.BtnTri.TabIndex = 1;
            this.BtnTri.Text = "3";
            this.BtnTri.UseVisualStyleBackColor = true;
            this.BtnTri.Click += new System.EventHandler(this.BtnTri_Click);
            // 
            // BtnCetiri
            // 
            this.BtnCetiri.Location = new System.Drawing.Point(13, 132);
            this.BtnCetiri.Name = "BtnCetiri";
            this.BtnCetiri.Size = new System.Drawing.Size(49, 45);
            this.BtnCetiri.TabIndex = 1;
            this.BtnCetiri.Text = "4";
            this.BtnCetiri.UseVisualStyleBackColor = true;
            this.BtnCetiri.Click += new System.EventHandler(this.BtnCetiri_Click);
            // 
            // BtnPet
            // 
            this.BtnPet.Location = new System.Drawing.Point(68, 132);
            this.BtnPet.Name = "BtnPet";
            this.BtnPet.Size = new System.Drawing.Size(49, 45);
            this.BtnPet.TabIndex = 1;
            this.BtnPet.Text = "5";
            this.BtnPet.UseVisualStyleBackColor = true;
            this.BtnPet.Click += new System.EventHandler(this.BtnPet_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(123, 132);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(49, 45);
            this.button6.TabIndex = 1;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // BtnSest
            // 
            this.BtnSest.Location = new System.Drawing.Point(123, 132);
            this.BtnSest.Name = "BtnSest";
            this.BtnSest.Size = new System.Drawing.Size(49, 45);
            this.BtnSest.TabIndex = 1;
            this.BtnSest.Text = "6";
            this.BtnSest.UseVisualStyleBackColor = true;
            this.BtnSest.Click += new System.EventHandler(this.BtnSest_Click);
            // 
            // BtnNula
            // 
            this.BtnNula.Location = new System.Drawing.Point(13, 233);
            this.BtnNula.Name = "BtnNula";
            this.BtnNula.Size = new System.Drawing.Size(49, 45);
            this.BtnNula.TabIndex = 1;
            this.BtnNula.Text = "0";
            this.BtnNula.UseVisualStyleBackColor = true;
            this.BtnNula.Click += new System.EventHandler(this.BtnNula_Click);
            // 
            // BtnDecimal
            // 
            this.BtnDecimal.Enabled = false;
            this.BtnDecimal.Location = new System.Drawing.Point(68, 233);
            this.BtnDecimal.Name = "BtnDecimal";
            this.BtnDecimal.Size = new System.Drawing.Size(49, 45);
            this.BtnDecimal.TabIndex = 1;
            this.BtnDecimal.Text = ".";
            this.BtnDecimal.UseVisualStyleBackColor = true;
            this.BtnDecimal.Click += new System.EventHandler(this.BtnDecimal_Click);
            // 
            // BtnMinus
            // 
            this.BtnMinus.Location = new System.Drawing.Point(232, 131);
            this.BtnMinus.Name = "BtnMinus";
            this.BtnMinus.Size = new System.Drawing.Size(50, 45);
            this.BtnMinus.TabIndex = 1;
            this.BtnMinus.Text = "-";
            this.BtnMinus.UseVisualStyleBackColor = true;
            this.BtnMinus.Click += new System.EventHandler(this.BtnMinus_Click);
            // 
            // BtnPlus
            // 
            this.BtnPlus.Location = new System.Drawing.Point(177, 131);
            this.BtnPlus.Name = "BtnPlus";
            this.BtnPlus.Size = new System.Drawing.Size(49, 45);
            this.BtnPlus.TabIndex = 1;
            this.BtnPlus.Text = "+";
            this.BtnPlus.UseVisualStyleBackColor = true;
            this.BtnPlus.Click += new System.EventHandler(this.BtnPlus_Click);
            // 
            // BtnMnozenje
            // 
            this.BtnMnozenje.Location = new System.Drawing.Point(177, 182);
            this.BtnMnozenje.Name = "BtnMnozenje";
            this.BtnMnozenje.Size = new System.Drawing.Size(50, 45);
            this.BtnMnozenje.TabIndex = 1;
            this.BtnMnozenje.Text = "•";
            this.BtnMnozenje.UseVisualStyleBackColor = true;
            this.BtnMnozenje.Click += new System.EventHandler(this.BtnMnozenje_Click);
            // 
            // BtnPodjeljeno
            // 
            this.BtnPodjeljeno.Location = new System.Drawing.Point(233, 182);
            this.BtnPodjeljeno.Name = "BtnPodjeljeno";
            this.BtnPodjeljeno.Size = new System.Drawing.Size(50, 45);
            this.BtnPodjeljeno.TabIndex = 1;
            this.BtnPodjeljeno.Text = "/";
            this.BtnPodjeljeno.UseVisualStyleBackColor = true;
            this.BtnPodjeljeno.Click += new System.EventHandler(this.BtnPodjeljeno_Click);
            // 
            // BtnSedam
            // 
            this.BtnSedam.Location = new System.Drawing.Point(13, 182);
            this.BtnSedam.Name = "BtnSedam";
            this.BtnSedam.Size = new System.Drawing.Size(49, 45);
            this.BtnSedam.TabIndex = 1;
            this.BtnSedam.Text = "7";
            this.BtnSedam.UseVisualStyleBackColor = true;
            this.BtnSedam.Click += new System.EventHandler(this.BtnSedam_Click);
            // 
            // BtnOsam
            // 
            this.BtnOsam.Location = new System.Drawing.Point(68, 183);
            this.BtnOsam.Name = "BtnOsam";
            this.BtnOsam.Size = new System.Drawing.Size(49, 45);
            this.BtnOsam.TabIndex = 1;
            this.BtnOsam.Text = "8";
            this.BtnOsam.UseVisualStyleBackColor = true;
            this.BtnOsam.Click += new System.EventHandler(this.BtnOsam_Click);
            // 
            // BtnDevet
            // 
            this.BtnDevet.Location = new System.Drawing.Point(123, 183);
            this.BtnDevet.Name = "BtnDevet";
            this.BtnDevet.Size = new System.Drawing.Size(49, 45);
            this.BtnDevet.TabIndex = 1;
            this.BtnDevet.Text = "9";
            this.BtnDevet.UseVisualStyleBackColor = true;
            this.BtnDevet.Click += new System.EventHandler(this.BtnDevet_Click);
            // 
            // BtnJednako
            // 
            this.BtnJednako.Location = new System.Drawing.Point(123, 233);
            this.BtnJednako.Name = "BtnJednako";
            this.BtnJednako.Size = new System.Drawing.Size(160, 45);
            this.BtnJednako.TabIndex = 1;
            this.BtnJednako.Text = "=";
            this.BtnJednako.UseVisualStyleBackColor = true;
            this.BtnJednako.Click += new System.EventHandler(this.BtnJednako_Click);
            // 
            // BtnOcisti
            // 
            this.BtnOcisti.Location = new System.Drawing.Point(177, 81);
            this.BtnOcisti.Name = "BtnOcisti";
            this.BtnOcisti.Size = new System.Drawing.Size(105, 45);
            this.BtnOcisti.TabIndex = 1;
            this.BtnOcisti.Text = "Clear";
            this.BtnOcisti.UseVisualStyleBackColor = true;
            this.BtnOcisti.Click += new System.EventHandler(this.BtnOcisti_Click);
            // 
            // TxtRezultat
            // 
            this.TxtRezultat.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtRezultat.Location = new System.Drawing.Point(13, 44);
            this.TxtRezultat.Name = "TxtRezultat";
            this.TxtRezultat.Size = new System.Drawing.Size(270, 32);
            this.TxtRezultat.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 286);
            this.Controls.Add(this.TxtRezultat);
            this.Controls.Add(this.BtnJedan);
            this.Controls.Add(this.BtnPodjeljeno);
            this.Controls.Add(this.BtnMnozenje);
            this.Controls.Add(this.BtnMinus);
            this.Controls.Add(this.BtnJednako);
            this.Controls.Add(this.BtnDecimal);
            this.Controls.Add(this.BtnOcisti);
            this.Controls.Add(this.BtnPlus);
            this.Controls.Add(this.BtnNula);
            this.Controls.Add(this.BtnDevet);
            this.Controls.Add(this.BtnOsam);
            this.Controls.Add(this.BtnSedam);
            this.Controls.Add(this.BtnSest);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.BtnPet);
            this.Controls.Add(this.BtnCetiri);
            this.Controls.Add(this.BtnTri);
            this.Controls.Add(this.BtnDva);
            this.Controls.Add(this.TxtKalkulator);
            this.Name = "Form1";
            this.Text = "Kontinuirani kalkulator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtKalkulator;
        private System.Windows.Forms.Button BtnDva;
        private System.Windows.Forms.Button BtnJedan;
        private System.Windows.Forms.Button BtnTri;
        private System.Windows.Forms.Button BtnCetiri;
        private System.Windows.Forms.Button BtnPet;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button BtnSest;
        private System.Windows.Forms.Button BtnNula;
        private System.Windows.Forms.Button BtnDecimal;
        private System.Windows.Forms.Button BtnMinus;
        private System.Windows.Forms.Button BtnPlus;
        private System.Windows.Forms.Button BtnMnozenje;
        private System.Windows.Forms.Button BtnPodjeljeno;
        private System.Windows.Forms.Button BtnSedam;
        private System.Windows.Forms.Button BtnOsam;
        private System.Windows.Forms.Button BtnDevet;
        private System.Windows.Forms.Button BtnJednako;
        private System.Windows.Forms.Button BtnOcisti;
        private System.Windows.Forms.TextBox TxtRezultat;
    }
}

