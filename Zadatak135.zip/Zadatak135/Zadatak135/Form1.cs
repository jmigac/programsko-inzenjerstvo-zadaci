﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadatak135
{
    public partial class Form1 : Form
    {
        public string SadrzajKalkulatora = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnJedan_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 1;
        }

        private void BtnDva_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 2;
        }

        private void BtnTri_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 3;
        }

        private void BtnCetiri_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 4;
        }

        private void BtnPet_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 5;
        }

        private void BtnSest_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 6;
        }

        private void BtnSedam_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 7;
        }

        private void BtnOsam_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 8;
        }

        private void BtnDevet_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 9;
        }

        private void BtnNula_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += 0;
        }

        private void BtnDecimal_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) <= 1)
                TxtKalkulator.Text += ".";
        }

        private void BtnPlus_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) < 1)
                TxtKalkulator.Text += "+";
        }

        private void BtnMinus_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) < 1)
                TxtKalkulator.Text += "-";
        }

        private void BtnMnozenje_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) < 1)
                TxtKalkulator.Text += "*";
        }

        private void BtnPodjeljeno_Click(object sender, EventArgs e)
        {
            if (Kalkulator.Status)
            {
                TxtKalkulator.Text = TxtRezultat.Text;
                Kalkulator.Status = false;
            }
            if (Kalkulator.BrojOperacija(TxtKalkulator.Text) < 1)
                TxtKalkulator.Text += "/";
        }

        private void BtnJednako_Click(object sender, EventArgs e)
        {
            Kalkulator.Izracunaj(TxtKalkulator.Text);
            TxtRezultat.Text = Kalkulator.VratiRezultat();
            Kalkulator.RezultatIzracuna = 0;
            Kalkulator.Izracun = 0;
        }

        private void BtnOcisti_Click(object sender, EventArgs e)
        {
            Kalkulator.OcistiPovijest();
            TxtKalkulator.Text = "";
            TxtRezultat.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Kalkulator.Izracun = 0;
            Kalkulator.RezultatIzracuna = 0;
        }
    }
}
