﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak135
{
    class Kalkulator
    {
        public static int Izracun { get; set; }
        public static string PovijestIzracuna { get; set; }
        public static int RezultatIzracuna { get; set; }
        public static bool Status { get; set; }
        public static int BrojOperacija(string sadrzaj)
        {
            int broj = 0;
            for (int i = 0; i < sadrzaj.Length; i++)
            {
                if (sadrzaj[i] == '+' || sadrzaj[i] == '-' || sadrzaj[i] == '/' || sadrzaj[i] == '*')
                    broj++;
            }
            return broj;
        }
        public static void Izracunaj(string sadrzajKalkulatora)
        {
            string operacija = "";
            string[] poljeBrojeva = new string[2];
            for (int i = 0; i < sadrzajKalkulatora.Length; i++)
            {
                switch (sadrzajKalkulatora[i])
                {
                    case '+':
                        {
                            operacija = "+";
                            break;
                        }
                    case '-':
                        {
                            operacija = "-";
                            break;
                        }
                    case '/':
                        {
                            operacija = "/";
                            break;
                        }
                    case '*':
                        {
                            operacija = "*";
                            break;
                        }
                }
            }
            poljeBrojeva = sadrzajKalkulatora.Split(operacija[0]);
            switch (operacija)
            {
                case "+":
                    {
                        Izracun = int.Parse(poljeBrojeva[0]) + int.Parse(poljeBrojeva[1]);
                        break;
                    }
                case "-":
                    {
                        Izracun = int.Parse(poljeBrojeva[0]) - int.Parse(poljeBrojeva[1]);
                        break;
                    }
                case "/":
                    {
                        Izracun = int.Parse(poljeBrojeva[0]) / int.Parse(poljeBrojeva[1]);
                        break;
                    }
                case "*":
                    {
                        Izracun = int.Parse(poljeBrojeva[0]) * int.Parse(poljeBrojeva[1]);
                        break;
                    }
            }
            RezultatIzracuna = Izracun;
            PovijestIzracuna += RezultatIzracuna;
            Status = true;
        }
        public static string VratiRezultat()
        {
            return RezultatIzracuna.ToString();
        }
        public static string VratiPovijestIzracuna()
        {
            return PovijestIzracuna;
        }
        public static void OcistiPovijest()
        {
            RezultatIzracuna = 0;
            Izracun = 0;
            PovijestIzracuna = "";
            Status = false;
        }
        public static bool SadrzajKalkulatoraSadrziOperaciju(string sadrzaj)
        {
            if (sadrzaj.Contains("+/*-"))
                return true;
            else return false;
        }
    }
}
