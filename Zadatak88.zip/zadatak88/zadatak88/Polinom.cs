﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak88
{
    class Polinom
    {
        public static List<Polinom> SviMonomi = new List<Polinom>();
        public int Broj { get; set; }
        private int _eksponent;
        public int Eksponent { get =>_eksponent;
            set
            {
                if (value == 0)
                    throw new EksponentJeNula("Unijeli ste broj koji poništava monom!");
                else
                    _eksponent = value;
            }
                }
        
        public Polinom(int skalar, int eksponent)
        {
            Broj = skalar;
            Eksponent = eksponent;
            SviMonomi.Add(this);
        }
        public override string ToString()
        {
            return " "+this.Broj.ToString() + "X^" + this.Eksponent.ToString()+" ";
        }
        public static void DerivacijaMonoma()
        {
            int eksponentTemp;
            int novaVrijednostSkalara;
            foreach (var monom in SviMonomi)
            {
                eksponentTemp = monom.Eksponent - 1;
                novaVrijednostSkalara = monom.Eksponent * monom.Broj;
                Console.Write($" {novaVrijednostSkalara}X^{eksponentTemp} ");
            }
            Console.WriteLine();
        }
    }
}
