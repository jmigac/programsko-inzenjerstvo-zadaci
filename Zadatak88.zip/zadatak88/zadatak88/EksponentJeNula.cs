﻿using System;
using System.Runtime.Serialization;

namespace zadatak88
{
    [Serializable]
    internal class EksponentJeNula : Exception
    {
        public EksponentJeNula()
        {
        }

        public EksponentJeNula(string message) : base(message)
        {
        }

        public EksponentJeNula(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected EksponentJeNula(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}