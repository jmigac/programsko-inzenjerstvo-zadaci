﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak88
{
    class Program
    {
        static void Main(string[] args)
        {
            string izborKorisnika = "";
            int skalar, eksponent;
            do
            {
                Console.WriteLine("1. unesi monom");
                Console.WriteLine("2. ispis polinoma");
                Console.WriteLine("3. ispis derivacije polinoma");
                Console.WriteLine("9. izlaz");
                Console.WriteLine("Odaberi:");
                izborKorisnika = Console.ReadLine();
                switch (izborKorisnika)
                {
                    case "1":
                        {
                            Console.WriteLine("Unesi broj:");
                            skalar = int.Parse(Console.ReadLine());
                            Console.WriteLine("Unesi eksponent:");
                            eksponent = int.Parse(Console.ReadLine());
                            Polinom noviPolinom = new Polinom(skalar, eksponent);
                            break;
                        }
                    case "2":
                        {
                            foreach (var monom in Polinom.SviMonomi)
                            {
                                Console.Write(monom.ToString());
                            }
                            Console.WriteLine();
                            break;
                        }
                    case "3":
                        {
                            Polinom.DerivacijaMonoma();
                            break;
                        }
                }
            } while (izborKorisnika != "9");
        }
    }
}
/*
1
3
3
1
2
3
1
5
4
1
-2
-8
*/