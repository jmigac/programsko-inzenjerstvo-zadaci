﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak99
{
    class Program
    {
        static void Main(string[] args)
        {
            string odabirIzbornika;
            string kategorija;
            int iznosTransakcije;
            do
            {
                Console.WriteLine("1. unesi transakciju");
                Console.WriteLine("2. ispis kategorizacije");
                Console.WriteLine("9. izlaz");
                Console.WriteLine("Odaberi:");
                odabirIzbornika = Console.ReadLine();
                switch (odabirIzbornika)
                {
                    case "1":
                        {
                            Console.WriteLine("Unesite kategoriju troška:");
                            kategorija = Console.ReadLine();
                            Console.WriteLine("Unesite trošak transakcije:");
                            iznosTransakcije = int.Parse(Console.ReadLine());
                            Kategorizacija novaKategorizacija = new Kategorizacija(iznosTransakcije, kategorija);
                            break;
                        }
                    case "2":
                        {

                            break;
                        }
                    case "3":
                        {
                            ;
                            foreach (var trosak in Kategorizacija.SveTransakcije)
                            {
                                Console.WriteLine(trosak.ToString());
                            }
                            break;
                        }
                }
            } while (odabirIzbornika != "9");
        }
    }
}
