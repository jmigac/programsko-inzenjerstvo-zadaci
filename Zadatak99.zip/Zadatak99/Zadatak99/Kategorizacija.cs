﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak99
{
    class Kategorizacija
    {
        //public static List<string> SveKategorije = new List<string>();
        public static List<Kategorizacija> SveTransakcije = new List<Kategorizacija>();
        public int Trosak { get=>_trosak;
            set
            {
                if (Trosak < -10000)
                {
                    throw new NeMozeBitiTakvaTransakcija("Želite napraviti nedozvoljenu transakciju!");

                }
                else
                    _trosak = value;
            }
                }
        private int _trosak;
        private string _kategorija;
        public string Kategorija { get; set; }
        public Kategorizacija(int iznosTransakcije, string kategorija)
        {
            Trosak = iznosTransakcije;
            Kategorija = kategorija;
            SveTransakcije.Add(this);
        }
        public override string ToString()
        {
            return Kategorija + " " + Trosak.ToString();
        }
        public static void KategorizacijaTroskova()
        {
            int iterator = SveTransakcije.Count;
            int iteratorStringa = 0;
            string[] KategorijeTransakcija = new string[iterator];
            int[] sumaTransakcija = new int[iterator];
            foreach (var transakcija in SveTransakcije)
            {
                for (int i = 0; i < iterator; i++)
                    if (KategorijeTransakcija[i].ToLower().Equals(transakcija.Kategorija.ToLower()))
                        SveTransakcije.Remove(transakcija);
                    else
                    {
                        KategorijeTransakcija[iteratorStringa] = 
                    }

            }
        }
    }
}
