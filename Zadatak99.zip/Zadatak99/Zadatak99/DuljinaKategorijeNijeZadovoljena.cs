﻿using System;
using System.Runtime.Serialization;

namespace Zadatak99
{
    [Serializable]
    internal class DuljinaKategorijeNijeZadovoljena : Exception
    {
        public DuljinaKategorijeNijeZadovoljena()
        {
        }

        public DuljinaKategorijeNijeZadovoljena(string message) : base(message)
        {
        }

        public DuljinaKategorijeNijeZadovoljena(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected DuljinaKategorijeNijeZadovoljena(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}