﻿using System;
using System.Runtime.Serialization;

namespace Zadatak99
{
    [Serializable]
    internal class NeMozeBitiTakvaTransakcija : Exception
    {
        public NeMozeBitiTakvaTransakcija()
        {
        }

        public NeMozeBitiTakvaTransakcija(string message) : base(message)
        {
        }

        public NeMozeBitiTakvaTransakcija(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected NeMozeBitiTakvaTransakcija(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}