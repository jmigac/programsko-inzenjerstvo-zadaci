﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak103
{
    class Automobili
    {
        public static List<Automobili> SviAutomobili = new List<Automobili>();
        public char Simbol { get; set; }
        public int BrzinaAutomobila { get; set; }

        public Automobili(char simbol, int brzina)
        {
            Simbol = simbol;
            BrzinaAutomobila = brzina;
            SviAutomobili.Add(this);
        }
        public static void SimulacijaUtrke()
        {
            foreach (var auto in SviAutomobili)
            {
                for (int i = 0; i < 100; i++)
                {
                    Console.Write(auto.Simbol);
                    System.Threading.Thread.Sleep(auto.BrzinaAutomobila);
                }
                Console.WriteLine();
             }
            Console.WriteLine();
        }
    }
}
