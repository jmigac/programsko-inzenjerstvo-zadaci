﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak103
{
    class Program
    {
        static void Main(string[] args)
        {
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.WriteLine("1. unos automobila");
                Console.WriteLine("9. kraj");
                Console.WriteLine("odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            int brojAutomobila,brzina;
                            char simbol;
                            Console.WriteLine("Unesite koliko automobila želite:");
                            brojAutomobila = int.Parse(Console.ReadLine());
                            for (int i = 0; i < brojAutomobila; i++)
                            {
                                Console.WriteLine("Unesi simbol auta:");
                                simbol = char.Parse(Console.ReadLine());
                                Console.WriteLine("Unesi brzinu auta:");
                                brzina = int.Parse(Console.ReadLine());
                                Automobili noviAuto = new Automobili(simbol,brzina);
                            }
                            Automobili.SimulacijaUtrke();
                            Console.ReadLine();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
/*
1
4
S
40
D
25
A
14
X
67
*/