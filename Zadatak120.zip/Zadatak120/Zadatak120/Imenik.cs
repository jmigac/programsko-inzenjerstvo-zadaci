﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak120
{
    class Imenik
    {
        public static List<Imenik> SviKorisnici = new List<Imenik>();
        public List<string> brojeviMobitela = new List<string>();
        public string ImePrezime { get; set; }
        public Imenik(string imePrezime)
        {
            ImePrezime = imePrezime;
            SviKorisnici.Add(this);
        }
        public static void IspisSvihKorisnica()
        {
            string korisnici = "";
            foreach (var korisnik in SviKorisnici)
            {
                korisnici += korisnik.ImePrezime + Environment.NewLine;
                foreach (var broj in korisnik.brojeviMobitela)
                {
                    korisnici += broj+Environment.NewLine;
                }
            }
            System.Windows.Forms.MessageBox.Show(korisnici);
        }
        public static Imenik NadiKorisnika(string imePrezime)
        {
            foreach (var korisnik in SviKorisnici)
            {
                if (korisnik.ImePrezime.ToLower().Equals(imePrezime.ToLower()))
                    return korisnik;
            }
            return null;
        }
    }
}
