﻿namespace Zadatak120
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtUnosKontakta = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnUnosKontakta = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TxtDodjelaImenu = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtDodjelaBroja = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.BtnDodjela = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ListaBrojeviKorisnika = new System.Windows.Forms.ListBox();
            this.TxtImePrezimePretrage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BtnPretragaKorisnika = new System.Windows.Forms.Button();
            this.BtnResetPretrage = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // TxtUnosKontakta
            // 
            this.TxtUnosKontakta.Location = new System.Drawing.Point(13, 31);
            this.TxtUnosKontakta.Name = "TxtUnosKontakta";
            this.TxtUnosKontakta.Size = new System.Drawing.Size(188, 20);
            this.TxtUnosKontakta.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ime i prezime:";
            // 
            // BtnUnosKontakta
            // 
            this.BtnUnosKontakta.Location = new System.Drawing.Point(13, 57);
            this.BtnUnosKontakta.Name = "BtnUnosKontakta";
            this.BtnUnosKontakta.Size = new System.Drawing.Size(188, 23);
            this.BtnUnosKontakta.TabIndex = 2;
            this.BtnUnosKontakta.Text = "Unesi kontakt";
            this.BtnUnosKontakta.UseVisualStyleBackColor = true;
            this.BtnUnosKontakta.Click += new System.EventHandler(this.BtnUnosKontakta_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TxtUnosKontakta);
            this.groupBox1.Controls.Add(this.BtnUnosKontakta);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(1, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(208, 89);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Unos kontatka";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BtnDodjela);
            this.groupBox2.Controls.Add(this.TxtDodjelaBroja);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.TxtDodjelaImenu);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(1, 100);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(208, 136);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Dodjela broja kontatku";
            // 
            // TxtDodjelaImenu
            // 
            this.TxtDodjelaImenu.Location = new System.Drawing.Point(13, 33);
            this.TxtDodjelaImenu.Name = "TxtDodjelaImenu";
            this.TxtDodjelaImenu.Size = new System.Drawing.Size(188, 20);
            this.TxtDodjelaImenu.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ime i prezime:";
            // 
            // TxtDodjelaBroja
            // 
            this.TxtDodjelaBroja.Location = new System.Drawing.Point(13, 76);
            this.TxtDodjelaBroja.Name = "TxtDodjelaBroja";
            this.TxtDodjelaBroja.Size = new System.Drawing.Size(188, 20);
            this.TxtDodjelaBroja.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Broj mobitela:";
            // 
            // BtnDodjela
            // 
            this.BtnDodjela.Location = new System.Drawing.Point(13, 102);
            this.BtnDodjela.Name = "BtnDodjela";
            this.BtnDodjela.Size = new System.Drawing.Size(188, 23);
            this.BtnDodjela.TabIndex = 3;
            this.BtnDodjela.Text = "Dodjeli broj";
            this.BtnDodjela.UseVisualStyleBackColor = true;
            this.BtnDodjela.Click += new System.EventHandler(this.BtnDodjela_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(14, 242);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(188, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Ispis svih kontakata";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ListaBrojeviKorisnika
            // 
            this.ListaBrojeviKorisnika.FormattingEnabled = true;
            this.ListaBrojeviKorisnika.Location = new System.Drawing.Point(215, 114);
            this.ListaBrojeviKorisnika.Name = "ListaBrojeviKorisnika";
            this.ListaBrojeviKorisnika.Size = new System.Drawing.Size(202, 147);
            this.ListaBrojeviKorisnika.TabIndex = 8;
            // 
            // TxtImePrezimePretrage
            // 
            this.TxtImePrezimePretrage.Location = new System.Drawing.Point(215, 35);
            this.TxtImePrezimePretrage.Name = "TxtImePrezimePretrage";
            this.TxtImePrezimePretrage.Size = new System.Drawing.Size(202, 20);
            this.TxtImePrezimePretrage.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(215, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ime i prezime:";
            // 
            // BtnPretragaKorisnika
            // 
            this.BtnPretragaKorisnika.Location = new System.Drawing.Point(215, 61);
            this.BtnPretragaKorisnika.Name = "BtnPretragaKorisnika";
            this.BtnPretragaKorisnika.Size = new System.Drawing.Size(202, 23);
            this.BtnPretragaKorisnika.TabIndex = 10;
            this.BtnPretragaKorisnika.Text = "Pretraga korisnika";
            this.BtnPretragaKorisnika.UseVisualStyleBackColor = true;
            this.BtnPretragaKorisnika.Click += new System.EventHandler(this.BtnPretragaKorisnika_Click);
            // 
            // BtnResetPretrage
            // 
            this.BtnResetPretrage.Location = new System.Drawing.Point(215, 85);
            this.BtnResetPretrage.Name = "BtnResetPretrage";
            this.BtnResetPretrage.Size = new System.Drawing.Size(202, 23);
            this.BtnResetPretrage.TabIndex = 11;
            this.BtnResetPretrage.Text = "Resetiranje pretrage";
            this.BtnResetPretrage.UseVisualStyleBackColor = true;
            this.BtnResetPretrage.Click += new System.EventHandler(this.BtnResetPretrage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(429, 288);
            this.Controls.Add(this.BtnResetPretrage);
            this.Controls.Add(this.BtnPretragaKorisnika);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TxtImePrezimePretrage);
            this.Controls.Add(this.ListaBrojeviKorisnika);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Imenik";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtUnosKontakta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnUnosKontakta;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BtnDodjela;
        private System.Windows.Forms.TextBox TxtDodjelaBroja;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxtDodjelaImenu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox ListaBrojeviKorisnika;
        private System.Windows.Forms.TextBox TxtImePrezimePretrage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnPretragaKorisnika;
        private System.Windows.Forms.Button BtnResetPretrage;
    }
}

