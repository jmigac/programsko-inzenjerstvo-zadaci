﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadatak120
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnUnosKontakta_Click(object sender, EventArgs e)
        {
            if (TxtUnosKontakta.Text.Length > 1)
            {
                Imenik noviKontakt = new Imenik(TxtUnosKontakta.Text);
                TxtUnosKontakta.Text = "";
                TxtUnosKontakta.Focus();
            }
            else
            {
                MessageBox.Show("Nepropisno uneseno ime!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Imenik.IspisSvihKorisnica();
        }

        private void BtnDodjela_Click(object sender, EventArgs e)
        {
            if (TxtDodjelaImenu.Text.Length > 1)
            {
                Imenik noviKorisnik = Imenik.NadiKorisnika(TxtDodjelaImenu.Text);
                if (noviKorisnik != null)
                {
                    noviKorisnik.brojeviMobitela.Add(TxtDodjelaBroja.Text);
                    TxtDodjelaImenu.Text = "";
                    TxtDodjelaBroja.Text = "";
                    TxtDodjelaImenu.Focus();
                }
                else
                {
                    MessageBox.Show("Korisnik ne postoji!");
                }
            }
        }

        private void BtnPretragaKorisnika_Click(object sender, EventArgs e)
        {
            if (TxtImePrezimePretrage.Text.Length > 1)
            {
                Imenik korisnik = Imenik.NadiKorisnika(TxtImePrezimePretrage.Text);
                if (korisnik != null)
                {
                    foreach (var broj in korisnik.brojeviMobitela)
                    {
                        ListaBrojeviKorisnika.Items.Add(broj);
                    }
                    TxtImePrezimePretrage.Text = "";
                    TxtImePrezimePretrage.Focus();
                }
                else
                {
                    MessageBox.Show("Korisnik ne postoji!");
                }
            }
            else
            {
                MessageBox.Show("Niste unijeli ime i prezime za pretragu!");
            }
        }

        private void BtnResetPretrage_Click(object sender, EventArgs e)
        {
             ListaBrojeviKorisnika.Items.Clear();
        }
    }
}
