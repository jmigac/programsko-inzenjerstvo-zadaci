﻿namespace Zadatak109
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListaBoja = new System.Windows.Forms.ListBox();
            this.TextBoxNazivBoje = new System.Windows.Forms.TextBox();
            this.GumbUnosBoja = new System.Windows.Forms.Button();
            this.GumbMijenjanjeBoja = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ListaBoja
            // 
            this.ListaBoja.FormattingEnabled = true;
            this.ListaBoja.Location = new System.Drawing.Point(12, 12);
            this.ListaBoja.Name = "ListaBoja";
            this.ListaBoja.Size = new System.Drawing.Size(133, 290);
            this.ListaBoja.TabIndex = 0;
            // 
            // TextBoxNazivBoje
            // 
            this.TextBoxNazivBoje.Location = new System.Drawing.Point(151, 32);
            this.TextBoxNazivBoje.Name = "TextBoxNazivBoje";
            this.TextBoxNazivBoje.Size = new System.Drawing.Size(187, 20);
            this.TextBoxNazivBoje.TabIndex = 1;
            // 
            // GumbUnosBoja
            // 
            this.GumbUnosBoja.Location = new System.Drawing.Point(152, 59);
            this.GumbUnosBoja.Name = "GumbUnosBoja";
            this.GumbUnosBoja.Size = new System.Drawing.Size(186, 23);
            this.GumbUnosBoja.TabIndex = 2;
            this.GumbUnosBoja.Text = "Unesi boju";
            this.GumbUnosBoja.UseVisualStyleBackColor = true;
            this.GumbUnosBoja.Click += new System.EventHandler(this.GumbUnosBoja_Click);
            // 
            // GumbMijenjanjeBoja
            // 
            this.GumbMijenjanjeBoja.Location = new System.Drawing.Point(152, 88);
            this.GumbMijenjanjeBoja.Name = "GumbMijenjanjeBoja";
            this.GumbMijenjanjeBoja.Size = new System.Drawing.Size(186, 214);
            this.GumbMijenjanjeBoja.TabIndex = 3;
            this.GumbMijenjanjeBoja.Text = "Mijenjaj boje";
            this.GumbMijenjanjeBoja.UseVisualStyleBackColor = true;
            this.GumbMijenjanjeBoja.Click += new System.EventHandler(this.GumbMijenjanjeBoja_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(152, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Unesi boju:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 313);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GumbMijenjanjeBoja);
            this.Controls.Add(this.GumbUnosBoja);
            this.Controls.Add(this.TextBoxNazivBoje);
            this.Controls.Add(this.ListaBoja);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox ListaBoja;
        private System.Windows.Forms.TextBox TextBoxNazivBoje;
        private System.Windows.Forms.Button GumbUnosBoja;
        private System.Windows.Forms.Button GumbMijenjanjeBoja;
        private System.Windows.Forms.Label label1;
    }
}

