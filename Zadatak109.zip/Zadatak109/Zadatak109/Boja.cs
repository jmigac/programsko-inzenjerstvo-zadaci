﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak109
{
    class Boja
    {
        public static List<Boja> SveBoje = new List<Boja>();
        public string NazivBoje { get; set; }

        public Boja(string boja)
        {
            NazivBoje = boja;
            SveBoje.Add(this);
        
        }
        public static Boja VratiBoju(string nazivBoja)
        {
            Boja bojaZaVratiti = null;
            foreach (var boja in SveBoje)
            {
                if (boja.NazivBoje.ToLower().Equals(nazivBoja.ToLower()))
                    bojaZaVratiti = boja;
            }
            return bojaZaVratiti;
        }
        public static bool ProvjeriDuplikatBoje(string nazivBoje)
        {
            bool vratiVrijednost = false;
            foreach (var boja in SveBoje)
            {
                if (boja.NazivBoje.ToLower().Equals(nazivBoje.ToLower()))
                    vratiVrijednost = true;
            }
            return vratiVrijednost;
        }
    }
}
