﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadatak109
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void GumbUnosBoja_Click(object sender, EventArgs e)
        {
            Boja novaBoja = new Boja(TextBoxNazivBoje.Text.ToLower());
            ListaBoja.Items.Add(TextBoxNazivBoje.Text.ToString().ToLower() + Environment.NewLine);
            TextBoxNazivBoje.Text = "";
        }

        private void GumbMijenjanjeBoja_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                foreach (var boja in Boja.SveBoje)
                {
                    if (boja.NazivBoje.Equals("crvena"))
                        this.BackColor = Color.Red;
                    if (boja.NazivBoje.Equals("plava"))
                        this.BackColor = Color.Blue;
                    if (boja.NazivBoje.Equals("crna"))
                        this.BackColor = Color.Black;
                    if (boja.NazivBoje.Equals("zelena"))
                        this.BackColor = Color.Green;
                    if (boja.NazivBoje.Equals("zuta"))
                        this.BackColor = Color.Yellow;
                    MessageBox.Show(boja.NazivBoje);
                    
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
