﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak134
{
    class Trosak
    {
        public static List<Trosak> SviTroskovi = new List<Trosak>();
        public string KategorijaTroska { get; set; }
        public double IznosTroska { get; set; }
        public Trosak(double iznos, string kategorija)
        {
            KategorijaTroska = kategorija;
            IznosTroska = iznos;
            SviTroskovi.Add(this);
        }
    }
}
