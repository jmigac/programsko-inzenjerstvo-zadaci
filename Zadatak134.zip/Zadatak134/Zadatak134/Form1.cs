﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadatak134
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnUnesiTrosak_Click(object sender, EventArgs e)
        {
            if (TxtIznosTroska.Text.Length != 0)
            {
                Trosak noviTrosak = new Trosak(double.Parse(TxtIznosTroska.Text), ComboKategorije.SelectedItem.ToString());
                TxtIznosTroska.Text = "";
                ComboKategorije.SelectedIndex = 0;
                TxtIznosTroska.Focus();
            }
        }

        private void BtnIspisTroskova_Click(object sender, EventArgs e)
        {
            foreach (var trosak in Trosak.SviTroskovi)
            {
                TxtSviTroskovi.Text += trosak.IznosTroska + "kn" + " - " + trosak.KategorijaTroska + Environment.NewLine;
            }
        }
    }
}
