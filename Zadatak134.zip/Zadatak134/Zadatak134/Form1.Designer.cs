﻿namespace Zadatak134
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnUnesiTrosak = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.ComboKategorije = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtIznosTroska = new System.Windows.Forms.TextBox();
            this.TxtSviTroskovi = new System.Windows.Forms.TextBox();
            this.BtnIspisTroskova = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnUnesiTrosak);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.ComboKategorije);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TxtIznosTroska);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(297, 149);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Unos podataka";
            // 
            // BtnUnesiTrosak
            // 
            this.BtnUnesiTrosak.Location = new System.Drawing.Point(7, 111);
            this.BtnUnesiTrosak.Name = "BtnUnesiTrosak";
            this.BtnUnesiTrosak.Size = new System.Drawing.Size(284, 32);
            this.BtnUnesiTrosak.TabIndex = 4;
            this.BtnUnesiTrosak.Text = "Unesi trošak";
            this.BtnUnesiTrosak.UseVisualStyleBackColor = true;
            this.BtnUnesiTrosak.Click += new System.EventHandler(this.BtnUnesiTrosak_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Kategorija troška:";
            // 
            // ComboKategorije
            // 
            this.ComboKategorije.FormattingEnabled = true;
            this.ComboKategorije.Items.AddRange(new object[] {
            "Hrana",
            "Zabava",
            "Zdravlje",
            "Edukacija"});
            this.ComboKategorije.Location = new System.Drawing.Point(7, 84);
            this.ComboKategorije.Name = "ComboKategorije";
            this.ComboKategorije.Size = new System.Drawing.Size(284, 21);
            this.ComboKategorije.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Iznos troška:";
            // 
            // TxtIznosTroska
            // 
            this.TxtIznosTroska.Location = new System.Drawing.Point(7, 40);
            this.TxtIznosTroska.Name = "TxtIznosTroska";
            this.TxtIznosTroska.Size = new System.Drawing.Size(284, 20);
            this.TxtIznosTroska.TabIndex = 0;
            // 
            // TxtSviTroskovi
            // 
            this.TxtSviTroskovi.Location = new System.Drawing.Point(12, 168);
            this.TxtSviTroskovi.Multiline = true;
            this.TxtSviTroskovi.Name = "TxtSviTroskovi";
            this.TxtSviTroskovi.Size = new System.Drawing.Size(297, 270);
            this.TxtSviTroskovi.TabIndex = 1;
            // 
            // BtnIspisTroskova
            // 
            this.BtnIspisTroskova.Location = new System.Drawing.Point(12, 444);
            this.BtnIspisTroskova.Name = "BtnIspisTroskova";
            this.BtnIspisTroskova.Size = new System.Drawing.Size(297, 32);
            this.BtnIspisTroskova.TabIndex = 5;
            this.BtnIspisTroskova.Text = "Ispis troškova";
            this.BtnIspisTroskova.UseVisualStyleBackColor = true;
            this.BtnIspisTroskova.Click += new System.EventHandler(this.BtnIspisTroskova_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(321, 483);
            this.Controls.Add(this.BtnIspisTroskova);
            this.Controls.Add(this.TxtSviTroskovi);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Kategorizacija troškova";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnUnesiTrosak;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox ComboKategorije;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtIznosTroska;
        private System.Windows.Forms.TextBox TxtSviTroskovi;
        private System.Windows.Forms.Button BtnIspisTroskova;
    }
}

