﻿using System;
using System.Runtime.Serialization;

namespace Zadatak77
{
    [Serializable]
    internal class CijenaNijeValidna : Exception
    {
        public CijenaNijeValidna()
        {
        }

        public CijenaNijeValidna(string message) : base(message)
        {
        }

        public CijenaNijeValidna(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected CijenaNijeValidna(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}