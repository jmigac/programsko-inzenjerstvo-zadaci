﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak77
{
    class Kosarica
    {
        public static List<Kosarica> SveKosarice = new List<Kosarica>();
        public List<Artikl> SviArtikliKosarice = new List<Artikl>();

        public Kosarica()
        {
            DodajArtikleUKosaricu();
            SveKosarice.Add(this);
        }
        private void DodajArtikleUKosaricu()
        {
            Artikl noviArtikl = null;
            string nazivArtikla;
            do
            {
                Console.WriteLine("Unesite naziv artikla:");
                nazivArtikla = Console.ReadLine();
                noviArtikl = Artikl.PronadiArtikl(nazivArtikla);
                if (noviArtikl == null)
                    break;
                SviArtikliKosarice.Add(noviArtikl);
                Console.WriteLine("Ponovan unos?");
                if (Console.ReadLine().ToLower() == "Ne".ToLower())
                    break;
            } while (true);
        }
        public static void IspisivanjeSvihArtiklovKosarice()
        {
            int i = 1;
            foreach (var kosarica in SveKosarice)
            {
                Console.WriteLine($"Sadrzaj {i}.te košarice:");
                foreach (var artikl in kosarica.SviArtikliKosarice)
                {
                    Console.WriteLine($"    {artikl.NazivArtikla}");
                }
                i++;
            }
        }
    }
}
