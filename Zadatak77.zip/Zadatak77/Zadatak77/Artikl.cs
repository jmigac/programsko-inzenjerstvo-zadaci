﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak77
{
    class Artikl
    {
        public static List<Artikl> SviArtikli = new List<Artikl>();
        public string NazivArtikla { get; set; }
        public double CijenaArtikla { get => _cijenaArtikla;
            set
            {
                if (value <= 0)
                    throw new CijenaNijeValidna("Unijeli ste krivu iznos za artikl!");
                else
                    _cijenaArtikla = value;
            }
        }
        private double _cijenaArtikla;

        public Artikl(string naziv, double cijena)
        {
            NazivArtikla = naziv;
            CijenaArtikla = cijena;
            SviArtikli.Add(this);
        }
        public static Artikl PronadiArtikl(string naziv)
        {
            Artikl vratiArtikl = null;
            foreach (var artikl in SviArtikli)
            {
                if (artikl.NazivArtikla.ToLower().Equals(naziv.ToLower()))
                    vratiArtikl = artikl;
            }
            return vratiArtikl;
        }
        public static void PretragaArtikala(string nazivArtikla)
        {
            foreach (var artikl in SviArtikli)
            {
                if (artikl.NazivArtikla.ToLower().Equals(nazivArtikla.ToLower()))
                {
                    Console.WriteLine($"{artikl.NazivArtikla} - {artikl.CijenaArtikla}");
                }
            }
        }
    }
}
