﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak77
{
    class Program
    {
        static void Main(string[] args)
        {
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("# === IZBORNIK === #");
                Console.WriteLine("1. unos artikla");
                Console.WriteLine("2. unos artikla u listu za kupovinu");
                Console.WriteLine("3. ispis artikala po kosarici");
                Console.WriteLine("4. pretraziti unesene artikle");
                Console.WriteLine("9. kraj");
                Console.WriteLine("Odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                Console.WriteLine("# === IZBORNIK === #");
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            Console.WriteLine("Naziv artikla:");
                            string nazivArtikla = Console.ReadLine();
                            Console.WriteLine("Cijena:");
                            double cijenaArtika = double.Parse(Console.ReadLine());
                            Artikl noviArtikl = new Artikl(nazivArtikla, cijenaArtika);
                            break;
                        }
                    case 2:
                        {
                            Kosarica novaKosarica = new Kosarica();
                            break;
                        }
                    case 3:
                        {
                            Kosarica.IspisivanjeSvihArtiklovKosarice();
                            Console.ReadKey();
                            break;
                        }
                    case 4:
                        {
                            string nazivArtikla;
                            Console.WriteLine("Unesi naziv artikla:");
                            nazivArtikla = Console.ReadLine();
                            Artikl.PretragaArtikala(nazivArtikla);
                            Console.ReadKey();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
/*
1
Cvjetaca
20
1
Kelj
23
1
Cokolada
200
1
Kruh
8
1
Pasteta
6.99
2
Kruh
da
Cokolada
ne
2
Cvjetaca
da
Kelj
da
Kruh
ne
*/
