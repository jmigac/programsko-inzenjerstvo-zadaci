﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak107
{
    class Brojevi
    {
        public static List<Brojevi> SviBrojevi = new List<Brojevi>();
        public int Broj { get; set; }

        public Brojevi(int broj)
        {
            Broj = broj;
            SviBrojevi.Add(this);
        }
        public static void IspisivanjeBrojeva()
        {
            foreach (var broj in SviBrojevi)
            {
                Console.Write($"{broj.Broj} ");
            }
        }
        private static double VracanjeAritmetickeSredine()
        {
            double aritmetickaSredina = 0;
            foreach (var broj in SviBrojevi)
            {
                aritmetickaSredina += broj.Broj;
            }
            aritmetickaSredina /= SviBrojevi.Count;
            return aritmetickaSredina;
        }
        private static double VracanjeApsolutnogOdstupanja(double aritmetickaSredina, int broj)
        {
            return Math.Abs(aritmetickaSredina - broj);
        }
        private static double VracanjeRelativnogOdstupanja(double aritmetickaSredina, int broj)
        {
            if (broj < aritmetickaSredina)
                return (broj / aritmetickaSredina) * 100;
            else
                return (aritmetickaSredina / broj) * 100;
        }
        public static void OdstupanjeVrijednosti()
        {
            double aritmetickaSredina = VracanjeAritmetickeSredine();
            Console.WriteLine("Aritmeticka sredina:{0}",aritmetickaSredina);
            foreach (var broj in SviBrojevi)
            {
                Console.WriteLine($"{broj.Broj} - Abs:{VracanjeApsolutnogOdstupanja(aritmetickaSredina,broj.Broj)} - Rel:{Math.Abs(VracanjeRelativnogOdstupanja(aritmetickaSredina,broj.Broj))}");
            }
        }
    }
}
