﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak107
{
    class Program
    {
        static void Main(string[] args)
        {
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.WriteLine("# === IZBORNIK === #");
                Console.WriteLine("1. unos broja");
                Console.WriteLine("2. ispis brojeva");
                Console.WriteLine("3. odstupanje od sredine");
                Console.WriteLine("9. kraj");
                Console.WriteLine("odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                Console.WriteLine("# === IZBORNIK === #");
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            Console.WriteLine("Unesi broj:");
                            int broj = int.Parse(Console.ReadLine());
                            Brojevi noviBroj = new Brojevi(broj);
                            break;
                        }
                    case 2:
                        {
                            Brojevi.IspisivanjeBrojeva();
                            Console.ReadLine();
                            break;
                        }
                    case 3:
                        {
                            Brojevi.OdstupanjeVrijednosti();
                            Console.ReadLine();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
/*
1
4
1
3
1
-3
1
8
1
10
1
16

*/