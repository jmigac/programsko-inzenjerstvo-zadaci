﻿using System;
using System.Runtime.Serialization;

namespace Zadatak108
{
    [Serializable]
    internal class UnijeliSteNeispravnuVrijednost : Exception
    {
        public UnijeliSteNeispravnuVrijednost()
        {
        }

        public UnijeliSteNeispravnuVrijednost(string message) : base(message)
        {
        }

        public UnijeliSteNeispravnuVrijednost(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected UnijeliSteNeispravnuVrijednost(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}