﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak108
{
    class Program
    {
        static void Main(string[] args)
        {
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("# === IZBORNIK === #");
                Console.WriteLine("1. unos");
                Console.WriteLine("2. ispis");
                Console.WriteLine("3. izvodenje");
                Console.WriteLine("9. kraj");
                Console.WriteLine("odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                Console.WriteLine("# === IZBORNIK === #");
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            int visina, sirina, trajanje;
                            Console.WriteLine("Unesi visinu:");
                            visina = int.Parse(Console.ReadLine());
                            Console.WriteLine("Unesi sirinu:");
                            sirina = int.Parse(Console.ReadLine());
                            Console.WriteLine("Unesi trajanje u ms:");
                            trajanje = int.Parse(Console.ReadLine());
                            Zaslon noviZaslon = new Zaslon(sirina, visina, trajanje);
                            break;
                        }
                    case 2:
                        {
                            Zaslon.IspisSvihDimenzija();
                            Console.ReadLine();
                            break;
                        }
                    case 3:
                        {
                            Zaslon.MjenjanjeDimenzijaKonzole();
                            Console.ReadLine();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
/*
1
33
45
500
1
60
23
600
1
40
23
300
1
10
63
450
1
44
53
550
*/
