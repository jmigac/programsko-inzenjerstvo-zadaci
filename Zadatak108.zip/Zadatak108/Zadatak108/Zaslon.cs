﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak108
{
    class Zaslon
    {
        public static List<Zaslon> SviZasloni = new List<Zaslon>();
        private int _sirina;
        private int _visina;
        public int Sirina
        {
            get => _sirina;
            set
            {
                if (value <= 0 && value > 63)
                    throw new UnijeliSteNeispravnuVrijednost("Zaslon je preuzak!");
                else
                    _sirina = value;
            }
        }
        public int Visina
        {
            get => _visina;
            set
            {
                if (value <= 0 && value > 63) 
                    throw new UnijeliSteNeispravnuVrijednost("Zaslon je preuzak!");
                else
                    _visina = value;
            }
        }
        public int Trajanje { get; set; }
        public Zaslon(int sirinaZaslona, int visinaZaslona, int trajanje)
        {
            Sirina = sirinaZaslona;
            Visina = visinaZaslona;
            Trajanje = trajanje;
            SviZasloni.Add(this);
        }
        public static void IspisSvihDimenzija()
        {
            foreach (var zaslon in SviZasloni)
            {
                Console.WriteLine($"{zaslon.Sirina} x {zaslon.Visina} - {zaslon.Trajanje}");
            }
        }
        public static void MjenjanjeDimenzijaKonzole()
        {
            while (true)
            {
                foreach (var zaslon in SviZasloni)
                {
                    Console.WindowHeight = zaslon.Visina;
                    Console.WindowWidth = zaslon.Sirina;
                    System.Threading.Thread.Sleep(zaslon.Trajanje);
                }
            }
        }
    }
}
