﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak85
{
    class Program
    {
        static void Main(string[] args)
        {
            string unosIzbornik;
            string mjesecTransakcije;
            string mjesecPretrageTransakcija;
            int iznosTransakcije;
            do
            {
                Console.WriteLine("1. unesi transkaciju");
                Console.WriteLine("2. ispis svih transakcija");
                Console.WriteLine("3. formatirani ispis transakcija");
                Console.WriteLine("4. pretraga transakcija");
                Console.WriteLine("9. izlaz iz aplikacijes");
                Console.WriteLine("Odaberi:");
                unosIzbornik = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.White;
                switch (unosIzbornik)
                {
                    case "1":
                        {
                            Console.WriteLine("Unesi iznos:");
                            iznosTransakcije = int.Parse(Console.ReadLine());
                            Console.WriteLine("Unesi mjesec transakcije");
                            mjesecTransakcije = Console.ReadLine();
                            Transakcija novaTransakcija = new Transakcija(iznosTransakcije, mjesecTransakcije);
                            break;
                        }
                    case "2":
                        {
                            foreach (var transakcija in Transakcija.SveTransakcije)
                            {
                                Console.WriteLine(transakcija.ToString());
                            }
                            Console.ForegroundColor = ConsoleColor.White;
                            break;
                        }
                    case "3":
                        {
                            Transakcija.TransakcijePoMjesecima();
                            break;
                        }
                    case "4":
                        {
                            Console.WriteLine("Unesi naziv mjeseca za pretragu:");
                            mjesecPretrageTransakcija = Console.ReadLine();
                            if (mjesecPretrageTransakcija.Length > 11)
                                throw new OvajMjesecNePostoji("Unijeli ste mjesec koji ne postoji!");
                            else
                                Transakcija.IspisSumeTransakcijeMjeseca(mjesecPretrageTransakcija);
                            break;
                        }
                }
            } while (unosIzbornik != "9");
        }
    }
}
/*
1
5000
Travanj
1
-2500
Ozujak
1
350
Travanj
1
-1000
Svibanj
*/