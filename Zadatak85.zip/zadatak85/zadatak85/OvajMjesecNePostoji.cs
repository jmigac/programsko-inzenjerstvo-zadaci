﻿using System;
using System.Runtime.Serialization;

namespace zadatak85
{
    [Serializable]
    internal class OvajMjesecNePostoji : Exception
    {
        public OvajMjesecNePostoji()
        {
        }

        public OvajMjesecNePostoji(string message) : base(message)
        {
        }

        public OvajMjesecNePostoji(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected OvajMjesecNePostoji(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}