﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak85
{
    class Transakcija
    {
        public static List<Transakcija> SveTransakcije = new List<Transakcija>();
        private bool VrstaTransakcije;
        private string _mjesecTransakcije;
        public int IznosTransakcije { get; set; }
        public string MjesecTransakcije
        {
            get => _mjesecTransakcije;
            set
            {
                if (value.Length < 11)
                    _mjesecTransakcije = value;
                else
                    throw new OvajMjesecNePostoji("Unijeli sve prevelik broj znakova za navedeni mjesec!");
            }
        }
        public Transakcija(int iznos, string mjesec)
        {
            IznosTransakcije = iznos;
            MjesecTransakcije = mjesec;
            if (iznos > 0)
                VrstaTransakcije = true;
            else
                VrstaTransakcije = false;
            SveTransakcije.Add(this);
        }
        public override string ToString()
        {
            if (VrstaTransakcije)
                Console.ForegroundColor = ConsoleColor.Green;
            else
                Console.ForegroundColor = ConsoleColor.Red;
            return this.IznosTransakcije.ToString() + " - " + this.MjesecTransakcije;
        }
        public static void TransakcijePoMjesecima()
        {
            string[] mjeseciGodine = new string[12] { "sijecanj", "veljaca", "ozujak", "travanj", "svibanj", "lipanj", "srpanj", "kolovoz", "rujan", "listopad", "studeni", "prosinac" };
            int[] iznosPoMjesecima = new int[12];
            for (int i = 0; i < 12; i++)
                iznosPoMjesecima[i] = 0;
            foreach (var transakcija in SveTransakcije)
            {
                for (int i = 0; i < 12; i++)
                {
                    if (transakcija.MjesecTransakcije.ToLower().Equals(mjeseciGodine[i]))
                        iznosPoMjesecima[i] += transakcija.IznosTransakcije;
                }
            }
            for (int i = 0; i < 12; i++)
            {
                if(iznosPoMjesecima[i]!=0)
                    Console.WriteLine($"{mjeseciGodine[i]} - {iznosPoMjesecima[i]}");
            }
        }
        public static void IspisSumeTransakcijeMjeseca(string mjesec)
        {
            string[] mjeseciGodine = new string[12] { "sijecanj", "veljaca", "ozujak", "travanj", "svibanj", "lipanj", "srpanj", "kolovoz", "rujan", "listopad", "studeni", "prosinac" };
            int[] iznosPoMjesecima = new int[12];
            for (int i = 0; i < 12; i++)
                iznosPoMjesecima[i] = 0;
            foreach (var transakcija in SveTransakcije)
            {
                for (int i = 0; i < 12; i++)
                {
                    if (transakcija.MjesecTransakcije.ToLower().Equals(mjeseciGodine[i]))
                        iznosPoMjesecima[i] += transakcija.IznosTransakcije;
                }

            }
            for (int i = 0; i < 12; i++)
            {
                if (mjesec.ToLower().Equals(mjeseciGodine[i].ToLower()))
                {
                    Console.WriteLine("Suma za {0} iznosi {1}", mjesec, iznosPoMjesecima[i]);
                    break;
                }

            }
        }
    }
}
