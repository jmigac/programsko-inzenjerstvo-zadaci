﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak91
{
    class Pravokutnik
    {
        public static List<Pravokutnik> SviPravokutnici = new List<Pravokutnik>();
        private double _stranicaA;
        private double _stranicaB;
        private double PovrsinaPravokutnika;
        private double OpsegPravokutnika;
        public double StranicaA { get => _stranicaA;
            set
            {
                if (value <= 0)
                {
                    throw new VrijednostManjaJednakaNuli("Veličina stranice je manja ili jednaka 0.");
                }
                else
                    _stranicaA = value;
            }
        }
        public double StranicaB { get => _stranicaB;
            set
            {
                if (value <= 0)
                {
                    throw new VrijednostManjaJednakaNuli("Veličina stranice je manja ili jednaka 0.");
                }
                else
                    _stranicaB = value;
            }
                }

        public Pravokutnik(double stranicaA, double stranicaB)
        {
            StranicaA = stranicaA;
            StranicaB = stranicaB;
            PovrsinaPravokutnika = this.StranicaA * this.StranicaB;
            OpsegPravokutnika = this.StranicaA * 2 + this.StranicaB * 2;
            SviPravokutnici.Add(this);
        }
        public override string ToString()
        {
            return this.StranicaA.ToString() + ":" + this.StranicaB.ToString() + " - " + PovrsinaPravokutnika.ToString() + " - " + OpsegPravokutnika.ToString();
        }
        public static void IspisPravokutnikaVecePovrsine(double upit)
        {
            foreach (var pravokutnik in SviPravokutnici)
            {
                if(pravokutnik.PovrsinaPravokutnika>upit)
                    Console.WriteLine($"{pravokutnik.StranicaA}:{pravokutnik.StranicaB}");
            }
        }
        public static void IspisPravokutnikaVecegOpsega(double upit)
        {
            foreach (var pravokutnik in SviPravokutnici)
            {
                if(pravokutnik.OpsegPravokutnika>upit)
                    Console.WriteLine($"{pravokutnik.StranicaA}:{pravokutnik.StranicaB}");
            }
        }
    }
}
