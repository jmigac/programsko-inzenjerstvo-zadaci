﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadatak91
{
    class Program
    {
        static void Main(string[] args)
        {
            string izborKorisnika = "";
            double stranicaA, stranicaB,upitPovrsina,upitOpseg;
            do
            {
                Console.WriteLine("1. upis pravokutnika");
                Console.WriteLine("2. ispis svih pravokutnika");
                Console.WriteLine("3. pravokutnik s povrsinom vece od X");
                Console.WriteLine("4. pravokutnik s opsegom vecim od Y");
                Console.WriteLine("9. izlaz");
                Console.WriteLine("Odaberi:");
                izborKorisnika = Console.ReadLine();
                switch (izborKorisnika)
                {
                    case "1":
                        {
                            Console.WriteLine("Unesi stranicu A:");
                            stranicaA = double.Parse(Console.ReadLine());
                            Console.WriteLine("Unesi stranicu B:");
                            stranicaB = double.Parse(Console.ReadLine());
                            Pravokutnik noviPravokutnik = new Pravokutnik(stranicaA,stranicaB);
                            break;
                        }
                    case "2":
                        {
                            foreach (var pravokutnik in Pravokutnik.SviPravokutnici)
                            {
                                Console.WriteLine(pravokutnik.ToString());
                            }
                            break;
                        }
                    case "3":
                        {
                            Console.WriteLine("Upisi površinu za poredbu:");
                            upitPovrsina = double.Parse(Console.ReadLine());
                            Pravokutnik.IspisPravokutnikaVecePovrsine(upitPovrsina);
                            break;
                        }
                    case "4":
                        {
                            Console.WriteLine("Upisi opseg za poredbu:");
                            upitOpseg = double.Parse(Console.ReadLine());
                            Pravokutnik.IspisPravokutnikaVecegOpsega(upitOpseg);
                            break;
                        }
                }
            } while (izborKorisnika != "9");
        }
    }
}
/*
1 
3.25
3.12
1
4.11
2.13
1
3.69
4.53
1
2.13
1.52

*/