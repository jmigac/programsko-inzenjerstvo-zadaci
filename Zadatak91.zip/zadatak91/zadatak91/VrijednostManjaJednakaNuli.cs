﻿using System;
using System.Runtime.Serialization;

namespace zadatak91
{
    [Serializable]
    internal class VrijednostManjaJednakaNuli : Exception
    {
        public VrijednostManjaJednakaNuli()
        {
        }

        public VrijednostManjaJednakaNuli(string message) : base(message)
        {
        }

        public VrijednostManjaJednakaNuli(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected VrijednostManjaJednakaNuli(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}