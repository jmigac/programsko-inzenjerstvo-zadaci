﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadatak110
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnPrepoznaj_Click(object sender, EventArgs e)
        {
            if (TxtPrvaRijec.Text.Equals(TxtDrugaRijec.Text) && TxtPrvaRijec.Text.Length > 1)
            {
                if(ProvjeriPalindrom())
                    MessageBox.Show("Navedene riječi su palindromi!");
                Statistika();
            }
            else
            {
                Statistika();
            }
        }
        private bool ProvjeriPalindrom()
        {
            string prvaRijec, drugaRijec;
            prvaRijec = TxtPrvaRijec.Text;
            drugaRijec = TxtDrugaRijec.Text;
            bool palindrom = false;
            if (prvaRijec.Length != drugaRijec.Length)
                return false;
            else
            {
                for (int i = 0; i < prvaRijec.Length; i++)
                {
                    if (prvaRijec[i].Equals(drugaRijec[drugaRijec.Length - 1 - i]))
                        palindrom = true;
                }
            }
            return palindrom;
        }
        private bool ProvjeriDuplikatSlova(List<char> listaSlova,char trazenoSlovo)
        {
            foreach (var slovo in listaSlova)
            {
                if (slovo.Equals(trazenoSlovo))
                    return true;
            }
            return false;
        }
        private void NabrojiPonavljanjeSlova(List<char> slova, int[] brojacSlova)
        {
            for (int i = 0; i < TxtPrvaRijec.Text.Length; i++)
            {
                for (int j = 0; j < slova.Count; j++)
                {
                    if (TxtPrvaRijec.Text[i].Equals(slova[j]))
                        brojacSlova[j]++;
                }
            }
            for (int i = 0; i < TxtDrugaRijec.Text.Length; i++)
            {
                for (int j = 0; j < slova.Count; j++)
                {
                    if (TxtDrugaRijec.Text[i].Equals(slova[j]))
                        brojacSlova[j]++;
                }
            }
        }
        private void InicijaliziracPolje(int[] poljeBrojeva)
        {
            for (int i = 0; i < poljeBrojeva.Length; i++)
            {
                poljeBrojeva[i] = 0;
            }
        }
        private void Statistika()
        {
            List<char> slova = new List<char>();
            if (TxtPrvaRijec.Text.Length.Equals(TxtDrugaRijec.Text.Length))
            {
                for (int i = 0; i < TxtPrvaRijec.Text.Length; i++)
                {
                    if (!ProvjeriDuplikatSlova(slova, TxtPrvaRijec.Text[i]))
                        slova.Add(TxtPrvaRijec.Text[i]);
                    if (!ProvjeriDuplikatSlova(slova, TxtDrugaRijec.Text[i]))
                        slova.Add(TxtDrugaRijec.Text[i]);
                }
            }
            else
            {
                for (int i = 0; i < TxtPrvaRijec.Text.Length; i++)
                {
                    if (!ProvjeriDuplikatSlova(slova, TxtPrvaRijec.Text[i]))
                        slova.Add(TxtPrvaRijec.Text[i]);
                }
                for (int i = 0; i < TxtDrugaRijec.Text.Length; i++)
                {
                    if (!ProvjeriDuplikatSlova(slova, TxtDrugaRijec.Text[i]))
                        slova.Add(TxtDrugaRijec.Text[i]);
                }
            }
            int[] brojacSlova = new int[slova.Count];
            InicijaliziracPolje(brojacSlova);
            NabrojiPonavljanjeSlova(slova, brojacSlova);
            string ispis = "";
            for (int i = 0; i < slova.Count; i++)
            {
                ispis += slova[i] + " - " + brojacSlova[i] + Environment.NewLine;
            }
            MessageBox.Show(ispis);
        }

        private void BtnResetiraj_Click(object sender, EventArgs e)
        {
            TxtPrvaRijec.Text = "";
            TxtDrugaRijec.Text = "";
            
        }
    }
}
