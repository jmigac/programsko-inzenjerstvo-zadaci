﻿namespace Zadatak110
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtPrvaRijec = new System.Windows.Forms.TextBox();
            this.TxtDrugaRijec = new System.Windows.Forms.TextBox();
            this.BtnPrepoznaj = new System.Windows.Forms.Button();
            this.BtnResetiraj = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtPrvaRijec
            // 
            this.TxtPrvaRijec.Location = new System.Drawing.Point(13, 13);
            this.TxtPrvaRijec.Name = "TxtPrvaRijec";
            this.TxtPrvaRijec.Size = new System.Drawing.Size(240, 20);
            this.TxtPrvaRijec.TabIndex = 0;
            // 
            // TxtDrugaRijec
            // 
            this.TxtDrugaRijec.Location = new System.Drawing.Point(12, 39);
            this.TxtDrugaRijec.Name = "TxtDrugaRijec";
            this.TxtDrugaRijec.Size = new System.Drawing.Size(240, 20);
            this.TxtDrugaRijec.TabIndex = 1;
            // 
            // BtnPrepoznaj
            // 
            this.BtnPrepoznaj.Location = new System.Drawing.Point(13, 66);
            this.BtnPrepoznaj.Name = "BtnPrepoznaj";
            this.BtnPrepoznaj.Size = new System.Drawing.Size(240, 23);
            this.BtnPrepoznaj.TabIndex = 2;
            this.BtnPrepoznaj.Text = "Prepoznaj";
            this.BtnPrepoznaj.UseVisualStyleBackColor = true;
            this.BtnPrepoznaj.Click += new System.EventHandler(this.BtnPrepoznaj_Click);
            // 
            // BtnResetiraj
            // 
            this.BtnResetiraj.Location = new System.Drawing.Point(12, 95);
            this.BtnResetiraj.Name = "BtnResetiraj";
            this.BtnResetiraj.Size = new System.Drawing.Size(240, 23);
            this.BtnResetiraj.TabIndex = 3;
            this.BtnResetiraj.Text = "Resetiraj";
            this.BtnResetiraj.UseVisualStyleBackColor = true;
            this.BtnResetiraj.Click += new System.EventHandler(this.BtnResetiraj_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(269, 129);
            this.Controls.Add(this.BtnResetiraj);
            this.Controls.Add(this.BtnPrepoznaj);
            this.Controls.Add(this.TxtDrugaRijec);
            this.Controls.Add(this.TxtPrvaRijec);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Prepoznavanje palindroma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtPrvaRijec;
        private System.Windows.Forms.TextBox TxtDrugaRijec;
        private System.Windows.Forms.Button BtnPrepoznaj;
        private System.Windows.Forms.Button BtnResetiraj;
    }
}

