﻿namespace Zadatak111
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Gumb = new System.Windows.Forms.Button();
            this.uiPrviTextBox = new System.Windows.Forms.TextBox();
            this.uiProtekloVrijeme = new System.Windows.Forms.Label();
            this.uiDrugiTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Gumb
            // 
            this.Gumb.Location = new System.Drawing.Point(38, 12);
            this.Gumb.Name = "Gumb";
            this.Gumb.Size = new System.Drawing.Size(230, 41);
            this.Gumb.TabIndex = 0;
            this.Gumb.Text = "POKRENI";
            this.Gumb.UseVisualStyleBackColor = true;
            this.Gumb.Click += new System.EventHandler(this.Gumb_Click);
            // 
            // uiPrviTextBox
            // 
            this.uiPrviTextBox.Location = new System.Drawing.Point(38, 59);
            this.uiPrviTextBox.Multiline = true;
            this.uiPrviTextBox.Name = "uiPrviTextBox";
            this.uiPrviTextBox.Size = new System.Drawing.Size(230, 63);
            this.uiPrviTextBox.TabIndex = 1;
            // 
            // uiProtekloVrijeme
            // 
            this.uiProtekloVrijeme.AutoSize = true;
            this.uiProtekloVrijeme.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uiProtekloVrijeme.Location = new System.Drawing.Point(12, 216);
            this.uiProtekloVrijeme.Name = "uiProtekloVrijeme";
            this.uiProtekloVrijeme.Size = new System.Drawing.Size(81, 29);
            this.uiProtekloVrijeme.TabIndex = 3;
            this.uiProtekloVrijeme.Text = "label1";
            this.uiProtekloVrijeme.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // uiDrugiTextBox
            // 
            this.uiDrugiTextBox.Location = new System.Drawing.Point(38, 141);
            this.uiDrugiTextBox.Multiline = true;
            this.uiDrugiTextBox.Name = "uiDrugiTextBox";
            this.uiDrugiTextBox.Size = new System.Drawing.Size(230, 63);
            this.uiDrugiTextBox.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 450);
            this.Controls.Add(this.uiDrugiTextBox);
            this.Controls.Add(this.uiProtekloVrijeme);
            this.Controls.Add(this.uiPrviTextBox);
            this.Controls.Add(this.Gumb);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Gumb;
        private System.Windows.Forms.TextBox uiPrviTextBox;
        private System.Windows.Forms.Label uiProtekloVrijeme;
        private System.Windows.Forms.TextBox uiDrugiTextBox;
    }
}

