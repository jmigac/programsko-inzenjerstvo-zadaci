﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zadatak111
{
    public partial class Form1 : Form
    {
        public static DateTime VrijemeUnosa = new DateTime();
        public Form1()
        {
            InitializeComponent();
        }

        private void Gumb_Click(object sender, EventArgs e)
        {
            uiProtekloVrijeme.Text = VrijemeUnosa.ToString();
            IteracijaUnosa();
        }
        public bool ProvjeraUnosa()
        {
            if (uiPrviTextBox.Text.ToLower().Equals(uiDrugiTextBox.Text.ToLower()))
                return true;
            else
                return false;
        }
        public void IteracijaUnosa()
        {
            while (true)
            {
                if (ProvjeraUnosa())
                    break;
            }
            uiProtekloVrijeme.Text = "Jednaki!";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
