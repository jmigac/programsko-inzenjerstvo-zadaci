﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak100
{
    class Kalkulator
    {
        public static List<Kalkulator> SviIzracuni = new List<Kalkulator>();
        public int PrviBroj { get; set; }
        public int DrugiBroj { get; set; }
        private char _operacija;
        public char Operacija { get=>_operacija;
            set
            {
                if ("+*-/".Contains(value.ToString()))
                    _operacija = value;
                else
                    throw new NePostojecaMatematickaOperacija("Unijeli ste operaciju koju kalkutor ne može obraditi!");
            }
                }
        public static void IspisiPovijest()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            foreach (var izracun in SviIzracuni)
            {
                Console.WriteLine($"{izracun.PrviBroj}{izracun.Operacija}{izracun.DrugiBroj} = {IzracunOperacije(izracun.PrviBroj,izracun.DrugiBroj,izracun.Operacija)}");
            }
            Console.WriteLine();
        }
        public static string IzracunOperacije(int prviBroj,int drugiBroj,char operacija)
        {
            switch (operacija)
            {
                case '+':
                    {
                        return (prviBroj + drugiBroj).ToString();
                       
                    }
                case '-':
                    {
                        return (prviBroj - drugiBroj).ToString();
                      
                    }
                case '*':
                    {
                        return (prviBroj * drugiBroj).ToString();
                        
                    }
                case '/':
                    {
                        return (prviBroj / drugiBroj).ToString();
                        
                    }
            }
            return "";
        }
        public void ObaviIzracun()
        {
            switch (this.Operacija)
            {
                case '+':
                    {
                        Console.WriteLine(this.PrviBroj+this.DrugiBroj);
                        break;
                    }
                case '-':
                    {
                        Console.WriteLine(this.PrviBroj-this.DrugiBroj);
                        break;
                    }
                case '*':
                    {
                        Console.WriteLine(this.PrviBroj*this.DrugiBroj);
                        break;
                    }
                case '/':
                    {
                        Console.WriteLine(this.PrviBroj/this.DrugiBroj);
                        break;
                    }
            }
        }
        public Kalkulator(int prviBroj, int drugiBroj, char operacija)
        {
            PrviBroj = prviBroj;
            DrugiBroj = drugiBroj;
            Operacija = operacija;
            SviIzracuni.Add(this);
            ObaviIzracun();
        }
    }
}
