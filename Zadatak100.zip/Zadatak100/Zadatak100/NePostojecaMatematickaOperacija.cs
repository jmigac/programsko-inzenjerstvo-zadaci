﻿using System;
using System.Runtime.Serialization;

namespace Zadatak100
{
    [Serializable]
    internal class NePostojecaMatematickaOperacija : Exception
    {
        public NePostojecaMatematickaOperacija()
        {
        }

        public NePostojecaMatematickaOperacija(string message) : base(message)
        {
        }

        public NePostojecaMatematickaOperacija(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected NePostojecaMatematickaOperacija(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}