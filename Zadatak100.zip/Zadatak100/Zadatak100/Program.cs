﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadatak100
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            "Napravite konzolnu aplikaciju koja je kontinuirani kalkulator koji osim rezultata ispisuje i povijest unosa uključujući i operaciju. (moguće operacije su +,-.*,/)
            U sklopu vašeg rješenja potrebno je napraviti i koristiti barem jednu iznimku"
            */
            int odabirIzbornika;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("# === IZBORNIK === #");
                Console.WriteLine("1. izračun");
                Console.WriteLine("2. ispis povijesti");
                Console.WriteLine("9. kraj");
                Console.WriteLine("Odaberi:");
                odabirIzbornika = int.Parse(Console.ReadLine());
                Console.WriteLine("# === IZBORNIK === #");
                switch (odabirIzbornika)
                {
                    case 1:
                        {
                            int prviBroj, drugiBroj;
                            char operacija;
                            Console.WriteLine("Unesi prvi broj:");
                            prviBroj = int.Parse(Console.ReadLine());
                            Console.WriteLine("Unesi operaciju:");
                            operacija = char.Parse(Console.ReadLine());
                            Console.WriteLine("Unesi drugi broj:");
                            drugiBroj = int.Parse(Console.ReadLine());
                            Kalkulator noviIzracun = new Kalkulator(prviBroj, drugiBroj, operacija);
                            Console.ReadLine();
                            break;
                        }
                    case 2:
                        {
                            Kalkulator.IspisiPovijest();
                            Console.ReadLine();
                            break;
                        }
                }
            } while (odabirIzbornika != 9);
        }
    }
}
/*
1
7
*
7
d
1
5
+
5
d
1
56
/
7
d
1
3
*
8
*/